const chalk = require('chalk');

const neonRed = '#FF0000'; // Kode warna neon merah

const port = chalk.hex(neonRed)('WELCOME TO FATZXC2');
const thread = chalk.hex(neonRed)('TYPE [HELP] TO SEE ALL TOLS');
const rps = chalk.hex(neonRed)('FOLLOW ME ON TELEGRAM : @FatzxService');

console.log(chalk.rgb(255, 0, 0)(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠄⠊⠁⠀⠀⠀⠀⠀⠈⠉⠐⠂⢄⡀⠀⠀⣀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡠⠊⢀⠀⠀⡀⠀⠀⣀⠀⠀⠀⠈⢄⠀⠐⠚⠲⣅⠀⠡⠀⠀⠀
⠀⠀⠀⠀⠔⠀⡠⠁⠀⡀⠐⢄⠀⠀⠑⣀⠀⠀⠀⢢⠀⠀⠀⢡⢧⠀⢆⠀⠀
⠀⠀⢀⡜⢀⢢⠃⡆⠰⠉⢀⠀⠩⡦⡀⠐⡆⠀⠀⠀⢣⢀⠄⡎⡌⡄⠸⠆⠀
⠀⠠⢀⠁⡸⡀⠀⡃⡄⠀⠀⠙⢦⡰⢬⠢⢹⠐⡀⠀⠀⢃⠰⠁⣇⢣⠀⡞⡀
⠀⠀⢸⠀⡇⠁⢠⢁⣇⠀⠀⠀⠁⠙⢞⣦⣄⡷⡅⠀⠀⠀⡧⡀⢹⢸⠀⠀⠃.            ${port}          
⠀⠀⡎⠀⡇⢠⢸⠌⡟⡀⠀⠀⠀⢀⡽⣿⡜⣇⡴⠀⠀⢠⡸⣨⣼⠀⡀⠀⠘.            ${thread}           
⠀⢀⡇⠀⢃⢸⢿⡀⢐⣀⠀⠀⠀⠀⠀⠘⠈⠀⢰⠈⠀⠀⣧⠓⣻⡆⠃⠀⠀.            ${rps}          
⠀⢸⡇⠀⠀⢼⣠⡿⣿⠿⡇⠀⠀⠀⠀⠀⠀⠀⢸⢠⡆⢰⡟⡜⣿⡧⢠⠀⠀
⠀⡀⡇⢠⠀⣼⣿⣅⠘⠁⠀⠀⠀⠀⠀⠀⠀⠀⠸⡏⠃⠀⡟⣷⣿⣧⠸⠀⠀
⠀⠃⡟⢸⡀⢻⣿⣷⣥⡀⠀⠀⠀⠘⠛⠁⠀⢀⠗⣰⠂⢸⠀⢏⣿⣿⠈⡆⠀
⠸⠀⢇⣿⣇⠸⣿⣿⣿⣿⡦⢀⠀⠀⠀⠀⠐⣡⢊⡞⡠⢇⣈⠔⠉⠈⠐⡇⠀
⠀⢸⢾⠋⣿⡀⢿⣿⣽⣿⡇⠀⠀⠉⢰⡖⡹⠽⠼⡯⠆⡟⠁⠀⠀⠀⠀⠀⠀
⠀⠊⡾⠀⢸⣿⣜⣿⣿⣿⡧⢀⠄⠀⠚⠊⠀⢀⠔⢁⡞⠀⡀⠀⠀⠀⠀⠀⠀
⠀⠈⠇⠀⠈⢿⣿⠿⡻⢛⢋⣁⣀⠀⠄⠐⠒⠣⠀⡾⢀⡔⠀⠀⠀⠀⠀⠀